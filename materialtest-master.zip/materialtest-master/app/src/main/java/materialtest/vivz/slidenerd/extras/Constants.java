package materialtest.vivz.slidenerd.extras;

/**
 * Created by Windows on 13-02-2015.
 */
public interface Constants {
    String NA = "NA";
}
