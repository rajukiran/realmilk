package materialtest.vivz.slidenerd.pojo;

/**
 * Created by Windows on 22-12-2014.
 */
public class Information {
    public int iconId;
    public String title;
}
