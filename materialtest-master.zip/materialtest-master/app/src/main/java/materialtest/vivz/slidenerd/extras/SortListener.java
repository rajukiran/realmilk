package materialtest.vivz.slidenerd.extras;

/**
 * Created by Windows on 18-02-2015.
 */
public interface SortListener {

    public void onSortByName();
    public void onSortByDate();
    public void onSortByRating();
}
