# LoginApp
Android Material design login and signup interfaces with validation rules.

###Included

- Material Design
- theme customization
- input validation
- login and signup interfaces

###Screenshots
<p align="center">
<img src="https://github.com/kasunbuddhima/LoginApp/blob/master/app/src/main/res/drawable/screenshot_1.png" width="350"/>
<img src="https://github.com/kasunbuddhima/LoginApp/blob/master/app/src/main/res/drawable/screenshot_2.png" width="350"/>
</p>
